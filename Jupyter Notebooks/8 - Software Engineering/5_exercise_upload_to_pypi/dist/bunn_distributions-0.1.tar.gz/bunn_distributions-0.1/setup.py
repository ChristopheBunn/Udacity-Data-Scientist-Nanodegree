from setuptools import setup

setup(name='bunn_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['bunn_distributions'],
      author = 'Christophe Bunn',
      author_email = 'christophe.bunn@gmail.com',
      zip_safe=False)
